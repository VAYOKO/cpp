import time
import psutil
import platform
from datetime import datetime
x = 0;
class bcolors:
    OK = '\033[92m' #GREEN
    WARNING = '\033[93m' #YELLOW
    FAIL = '\033[91m' #RED
    RESET = '\033[0m' #RESET COLOR


def get_size(bytes, suffix="B"):
    """
    Scale bytes to its proper format
    e.g:
        1253656 => '1.20MB'
        1253656678 => '1.17GB'
    """
    factor = 1024
    for unit in ["", "K", "M", "G", "T", "P"]:
        if bytes < factor:
            return f"{bytes:.2f}{unit}{suffix}"
        bytes /= factor


while True:
    
       #  __  __     __  __             __   __  
        #|__)/   __ /  \(_  __ \  / /\ |__)|(_   
        #|   \__    \__/__)     \/ /--\| \ |__)  
#                                                                                          
       #  _____   _____       ____   _____    __      __     _____  _____  _____  
       # |  __ \ / ____|     / __ \ / ____|   \ \    / /\   |  __ \|_   _|/ ____| 
       # | |__) | |   ______| |  | | (___ _____\ \  / /  \  | |__) | | | | (___   
       # |  ___/| |  |______| |  | |\___ \______\ \/ / /\ \ |  _  /  | |  \___ \  
       # | |    | |____     | |__| |____) |      \  / ____ \| | \ \ _| |_ ____) | 
       # |_|     \_____|     \____/|_____/        \/_/    \_\_|  \_\_____|_____/  
        #print(bcolors.OK + "File Saved Successfully!" + bcolors.RESET)
        #print(f"{bcolors.OK}File Saved Successfully!{bcolors.RESET}")
        
        print(f"{bcolors.OK} _____   _____       ____   _____    __      __     _____  _____  _____  {bcolors.RESET}")       
        print(f"{bcolors.WARNING}|  __ \ / ____|     / __ \ / ____|   \ \    / /\   |  __ \|_   _|/ ____| {bcolors.RESET}")  
        print(f"{bcolors.OK}| |__) | |   ______| |  | | (___ _____\ \  / /  \  | |__) | | | | (___   {bcolors.RESET}")     
        print(f"{bcolors.WARNING}|  ___/| |  |______| |  | |\___ \______\ \/ / /\ \ |  _  /  | |  \___ \  {bcolors.RESET}")     
        print(f"{bcolors.OK}| |    | |____     | |__| |____) |      \  / ____ \| | \ \ _| |_ ____) | {bcolors.RESET}") 
        print(f"{bcolors.WARNING}|_|     \_____|     \____/|_____/        \/_/    \_\_|  \_\_____|_____/  {bcolors.RESET}")                                             
        print(f"{bcolors.FAIL}varos- varis - pc  -  -  -  -  -  -  -  -!{bcolors.RESET}")
        time.sleep(5)
        
        print("The current date and time is: ",datetime.now())
        print("  ")
        print("="*40, "System Information", "="*40)
        uname = platform.uname()
        print(f"System: {uname.system}")
        print(f"Node Name: {uname.node}")
        print(f"Release: {uname.release}")
        print(f"Version: {uname.version}")
        print(f"Machine: {uname.machine}")
        print(f"Processor: {uname.processor}")
        # Boot Time
        print("="*40, "Boot Time", "="*40)
        boot_time_timestamp = psutil.boot_time()
        bt = datetime.fromtimestamp(boot_time_timestamp)
        print(f"Boot Time: {bt.year}/{bt.month}/{bt.day} {bt.hour}:{bt.minute}:{bt.second}")
        # let's print CPU information
        print("="*40, "CPU Info", "="*40)
        # number of cores
        print("Physical cores:", psutil.cpu_count(logical=False))
        print("Total cores:", psutil.cpu_count(logical=True))
        # CPU frequencies
        cpufreq = psutil.cpu_freq()
        print(f"Max Frequency: {cpufreq.max:.2f}Mhz")
        print(f"Min Frequency: {cpufreq.min:.2f}Mhz")
        print(f"Current Frequency: {cpufreq.current:.2f}Mhz")
        # CPU usage
        print("CPU Usage Per Core:")
        for i, percentage in enumerate(psutil.cpu_percent(percpu=True, interval=1)):
          print(f"Core {i}: {percentage}%")
        print(f"Total CPU Usage: {psutil.cpu_percent()}%")

        # Memory Information
        print("="*40, "Memory Information", "="*40)
        # get the memory details
        svmem = psutil.virtual_memory()
        print(f"Total: {get_size(svmem.total)}")
        print(f"Available: {get_size(svmem.available)}")
        print(f"Used: {get_size(svmem.used)}")
        print(f"Percentage: {svmem.percent}%")
        print("="*20, "SWAP", "="*20)
        # get the swap memory details (if exists)
        swap = psutil.swap_memory()
        print(f"Total: {get_size(swap.total)}")
        print(f"Free: {get_size(swap.free)}")
        print(f"Used: {get_size(swap.used)}")
        print(f"Percentage: {swap.percent}%")

        # Disk Information
        print("="*40, "Disk Information", "="*40)
        print("Partitions and Usage:")
        # get all disk partitions
        partitions = psutil.disk_partitions()
        for partition in partitions:
               print(f"=== Device: {partition.device} ===")
               print(f"  Mountpoint: {partition.mountpoint}")
               print(f"  File system type: {partition.fstype}")
               try:
                     partition_usage = psutil.disk_usage(partition.mountpoint)
               except PermissionError:
        # this can be catched due to the disk that
        # isn't ready
                    continue
               print(f"  Total Size: {get_size(partition_usage.total)}")
               print(f"  Used: {get_size(partition_usage.used)}")
               print(f"  Free: {get_size(partition_usage.free)}")
               print(f"  Percentage: {partition_usage.percent}%")
        # get IO statistics since boot
        disk_io = psutil.disk_io_counters()
        print(f"Total read: {get_size(disk_io.read_bytes)}")
        print(f"Total write: {get_size(disk_io.write_bytes)}")


               # Network information
        print("="*40, "Network Information", "="*40)
        # get all network interfaces (virtual and physical)
        if_addrs = psutil.net_if_addrs()
        for interface_name, interface_addresses in if_addrs.items():
           for address in interface_addresses:
                print(f"=== Interface: {interface_name} ===")
                if str(address.family) == 'AddressFamily.AF_INET':
                    print(f"  IP Address: {address.address}")
                    print(f"  Netmask: {address.netmask}")
                    print(f"  Broadcast IP: {address.broadcast}")
                elif str(address.family) == 'AddressFamily.AF_PACKET':
                    print(f"  MAC Address: {address.address}")
                    print(f"  Netmask: {address.netmask}")
                    print(f"  Broadcast MAC: {address.broadcast}")
#        get IO statistics since boot
        net_io = psutil.net_io_counters()
        print(f"Total Bytes Sent: {get_size(net_io.bytes_sent)}")
        print(f"Total Bytes Received: {get_size(net_io.bytes_recv)}")


        time.sleep(5)
        print(f"{bcolors.OK}#8888888b.   .d8888b.          .d88888b.   .d8888b.       888     888     d8888 8888888b.  8888888 .d8888b. ")
        print(f"{bcolors.OK}#888   Y88b d88P  Y88b        d88P   Y88b d88P  Y88b      888     888    d88888 888   Y88b   888  d88P  Y88b")
        print(f"{bcolors.OK}#888    888 888    888        888     888 Y88b.           888     888   d88P888 888    888   888  Y88b.     ")
        print(f"{bcolors.OK}#888   d88P 888               888     888   Y888b.        Y88b   d88P  d88P 888 888   d88P   888    Y888b.  ")
        print(f"{bcolors.OK}#8888888P   888               888     888      Y88b.       Y88b d88P  d88P  888 8888888P     888       Y88b.")
        print(f"{bcolors.OK}#888        888    888 888888 888     888        888 888888 Y88o88P  d88P   888 888 T88b     888         888")
        print(f"{bcolors.OK}#888        Y88b  d88P        Y88b. .d88P Y88b  d88P         Y888P  d8888888888 888  T88b    888  Y88b  d88P")
        print(f"{bcolors.OK}#888          Y8888P            Y88888P     Y8888P            Y8P  d88P     888 888   T88b 8888888  Y8888P  ")
        time.sleep(5)
        break
        
#8888888b.   .d8888b.          .d88888b.   .d8888b.       888     888     d8888 8888888b.  8888888 .d8888b.       
#888   Y88b d88P  Y88b        d88P" "Y88b d88P  Y88b      888     888    d88888 888   Y88b   888  d88P  Y88b      
#888    888 888    888        888     888 Y88b.           888     888   d88P888 888    888   888  Y88b.           
#888   d88P 888               888     888  "Y888b.        Y88b   d88P  d88P 888 888   d88P   888   "Y888b.        
#8888888P"  888               888     888     "Y88b.       Y88b d88P  d88P  888 8888888P"    888      "Y88b.      
#888        888    888 888888 888     888       "888 888888 Y88o88P  d88P   888 888 T88b     888        "888      
#888        Y88b  d88P        Y88b. .d88P Y88b  d88P         Y888P  d8888888888 888  T88b    888  Y88b  d88P      
#888         "Y8888P"          "Y88888P"   "Y8888P"           Y8P  d88P     888 888   T88b 8888888 "Y8888P"       
                  

        
#using the now function